import math
from random import random, seed
import matplotlib.pyplot as plt
from evacim import cim_acc_config as cfg
from evacim import area_modeling
from evacim import sim


def func_cima(acc0, gli, dataflow):
    m = sim.evaluate(acc0, gli, dataflow)
    return -m['throughput'], m['area'][7]*1e-6

def get_random_bool():
    dice = random()
    if dice<1/3: 
        return -1
    elif dice < 2/3: 
        return 0
    else:
        return 1

class SimulateAnnealing_CIMACC:
    def __init__(self, func, acc0, gli, dataflow, iter=5, T0=100, Tf=1e-8, alpha=0.99):
        """
        Annealing parameters
        :param iter: Number of internal cycles
        :param T0: Initial temperature
        :param Tf: Final temperature
        :param alpha: Cooling factor
        """
        self.func = func
        self.iter = iter
        self.alpha = alpha
        self.T0 = T0
        self.Tf = Tf
        self.T = T0

        self.accs = [acc0 for i in range(self.iter)]
        self.gli = gli
        self.dataflow = dataflow

        self.area_const = 5       
        self.ms_ratio = 0.1
        # 50 for ee_L2
        # 0.05 for throughput
        self.delta = {
            'macro_row': 1,
            'macro_col': 1,
            'scr': 4,
            'is_size': 4,
            'os_size': 4
        }
        # self.x = [random() * 10 for i in range(iter)]
        # self.y = [random() * 10 for i in range(iter)]
        self.history = {'f': [], 'T': []}

    def generate_new_acc(self, acc0):
        while True:
            macro_row_new = acc0.macro_row + get_random_bool()*self.delta['macro_row']
            macro_col_new = acc0.macro_col + get_random_bool()*self.delta['macro_col']
            scr_new = acc0.SCR + get_random_bool()*self.delta['scr']
            is_size_new = acc0.is_size + get_random_bool()*self.delta['is_size']
            os_size_new = acc0.os_size + get_random_bool()*self.delta['os_size']
            
            #print(macro_row_new, macro_col_new, scr_new, is_size_new, os_size_new)
            
            if macro_row_new > 0 and macro_col_new > 0 and scr_new > 0 and is_size_new > 0 and os_size_new > 0:
                acc_new = cfg.CIMACC(
                    cim = acc0.cim,
                    bus_width = acc0.bus_width,
                    macro_row = macro_row_new,
                    macro_col = macro_col_new,
                    scr = scr_new,
                    is_size = is_size_new,
                    os_size = os_size_new,
                    freq = acc0.freq
                    )
                area = area_modeling.area_modeling(acc_new)
                if area[7]*1e-6 <= self.area_const:
                    break
        return acc_new


    def Metrospolis(self, f, f_new):
        if f_new <= f:
            return 1
        else:
            p = math.exp((f - f_new) * self.ms_ratio / self.T)
            if random() < p:
                return 1
            else:
                return 0

    def get_optimal(self):
        f_list = []
        area_list = []
        for i in range(self.iter):
            f, area = self.func(acc0 = self.accs[i], gli = self.gli, dataflow = self.dataflow)
            f_list.append(f)
            area_list.append(area)
        f_best = min(f_list)
        idx = f_list.index(f_best)
        return - f_best, area_list[idx], idx

    def plot(self, xlim=None, ylim=None):
        plt.plot(self.history['T'], self.history['f'])
        plt.title('Simulate Annealing')
        plt.xlabel('Temperature')
        plt.ylabel('f value')
        if xlim:
            plt.xlim(xlim[0], xlim[-1])
        if ylim:
            plt.ylim(ylim[0], ylim[-1])
        plt.gca().invert_xaxis()
        plt.show()

    def run(self):
        count = 0
        # annealing
        while self.T > self.Tf:
            # iteration
            for i in range(self.iter):
                f, _ = self.func(acc0 = self.accs[i], gli = self.gli, dataflow = self.dataflow)
                acc_new = self.generate_new_acc(self.accs[i])
                f_new, _ = self.func(acc0 = acc_new, gli = self.gli, dataflow = self.dataflow)
                if self.Metrospolis(f, f_new):
                    self.accs[i] = acc_new
            # save to history
            ft, _, idx = self.get_optimal()
            self.history['f'].append(ft)
            self.history['T'].append(self.T)
            print(ft, self.T,'idx:',idx, self.accs[idx].macro_row, self.accs[idx].macro_col, self.accs[idx].SCR, self.accs[idx].IS_DEPTH, self.accs[idx].OS_DEPTH)
            # cooling
            self.T = self.T * self.alpha
            count += 1
        # get optimal solution
        f_best, area, idx = self.get_optimal()
        self.accs[idx].printf()
        print(f"EE_best={f_best}, area={area}", count)

if __name__ == '__main__':
 
    trancim = cfg.CIM("./cim_config/TranCIM.cfg")
    gli = ['proj', [512,512,512]]
    acc_trancim = cfg.CIMACC(
        trancim,
        bus_width = 25.6, 
        macro_row = 3, 
        macro_col = 1, 
        scr = 1, 
        is_size = 64, 
        os_size = 128, 
        freq=200
        ) 

    seed(42)
    sa = SimulateAnnealing_CIMACC(func_cima, acc_trancim, gli, "isap", iter=5, Tf=1, alpha=0.99)
    
    sa.run()
    sa.plot()

