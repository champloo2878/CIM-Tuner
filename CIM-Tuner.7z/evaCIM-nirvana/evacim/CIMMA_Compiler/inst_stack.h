#ifndef INST_STACK_H
#define INST_STACK_H

#define STACK_LEN 10
#define FILENAME_SIZE 20

// ����ָ���ջ�ṹ
typedef struct {
    int len;
    char inst_fifo[STACK_LEN][256]; // ����ָ�����󳤶�Ϊ256
    int req_queue[STACK_LEN];
    int addr_queue[STACK_LEN];
    int preq_queue[STACK_LEN];
    int paddr_queue[STACK_LEN];
    char filename[FILENAME_SIZE];
} InstStack;

int Verify(const char *inst, int new_addr);
void InitInstStack(InstStack *stack, int len, const char *filename);
void PushInstStack(InstStack *stack, const char *inst, int rd_req, int rd_addr);
void CheckInstStack(const InstStack *stack);

#endif // INST_STACK_H
