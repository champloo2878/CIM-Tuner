from evacim import sim
from random import random
import numpy as np

from evacim import cim_acc_config as ccfg
from evacim import nn_config as ncfg

def func_model(acc0, model, opt_target):
    num_ind_layer = len(model.gli_list_rdc)
    m_layer_rec = [[] for i in range(num_ind_layer)]
    df_rec = [[] for i in range(num_ind_layer)]

    total_energy = 0
    total_op = 0
    total_delay = 0

    for i in range(num_ind_layer):
        dims = tuple(int(x) for x in model.gli_list_rdc[i])
        gli = ('proj', dims)
        m_layer_rec[i], df_rec[i] = block_decision(acc0, gli, opt_target)
        total_energy += m_layer_rec[i]['energy_L2']*model.gli_cnt[i]
        total_op += m_layer_rec[i]['op']*model.gli_cnt[i]
        total_delay += m_layer_rec[i]['latency']*model.gli_cnt[i]
        
        # print(model.gli_list_rdc[i])
        # print(m_layer_rec[i]['ee_L2'])

    area = m_layer_rec[0]['area'][7]

    if opt_target == 'ee_L2':
        return - total_op/total_energy, df_rec, area
    elif opt_target == 'throughput':
        return - total_op/total_delay, df_rec, area
    elif opt_target == 'EDP':
        return total_delay*total_energy/1e12, df_rec, area
    else:
        return - total_op/total_energy, df_rec, area


def func_model_fix_dataflow(acc0, model, opt_target):
    num_ind_layer = len(model.gli_list_rdc)
    m_layer_rec = [[] for i in range(num_ind_layer)]
    df_rec = [[] for i in range(num_ind_layer)]

    total_energy = 0
    total_op = 0
    total_delay = 0

    for i in range(num_ind_layer):
        dims = tuple(int(x) for x in model.gli_list_rdc[i])
        gli = ('proj', dims)
        m_layer_rec[i], df_rec[i] = block_decision(acc0, gli, opt_target, fix = True)
        total_energy += m_layer_rec[i]['energy_L2']*model.gli_cnt[i]
        total_op += m_layer_rec[i]['op']*model.gli_cnt[i]
        total_delay += m_layer_rec[i]['latency']*model.gli_cnt[i]

    area = m_layer_rec[0]['area'][7]

    if opt_target == 'ee_L2':
        return - total_op/total_energy, df_rec, area
    elif opt_target == 'throughput':
        return - total_op/total_delay, df_rec, area
    elif opt_target == 'EDP':
        return total_delay*total_energy/1e12, df_rec, area
    else:
        return - total_op/total_energy, df_rec, area


def block_decision(acc0, gli, opt_target='ee_L2', fix=False):
    if fix == True:
        m_rec = [[] for i in range(4)]
        dataflow = ['isap','wsap','r_isap','r_wsap']
        m_rec[0] = sim.evaluate(acc0, gli, dataflow[0])
        m_rec[1] = sim.evaluate(acc0, gli, dataflow[1])
        rv_gli = (gli[0],(gli[1][2],gli[1][1],gli[1][0]))
        m_rec[2] = sim.evaluate(acc0, rv_gli, dataflow[0])
        m_rec[3] = sim.evaluate(acc0, rv_gli, dataflow[1])
        
        cmpme = np.zeros(4)
        for i in range(4):
            cmpme[i] = m_rec[i][opt_target]
        idx = np.argmin(cmpme)
    
        return m_rec[idx], dataflow[idx]
    
    else:
        m_rec = [[] for i in range(8)]
        dataflow = ['isap','ispp','wsap','wspp','r_isap','r_ispp','r_wsap','r_wspp']
        m_rec[0] = sim.evaluate(acc0, gli, 'isap')
        m_rec[1] = sim.evaluate(acc0, gli, 'ispp')
        m_rec[2] = sim.evaluate(acc0, gli, 'wsap')
        m_rec[3] = sim.evaluate(acc0, gli, 'wspp')

        rv_gli = (gli[0],(gli[1][2],gli[1][1],gli[1][0]))
        m_rec[4] = sim.evaluate(acc0, rv_gli, 'isap')
        m_rec[5] = sim.evaluate(acc0, rv_gli, 'ispp')
        m_rec[6] = sim.evaluate(acc0, rv_gli, 'wsap')
        m_rec[7] = sim.evaluate(acc0, rv_gli, 'wspp')
    
        cmpme = np.zeros(8)
        for i in range(8):
            cmpme[i] = m_rec[i][opt_target]
        idx = np.argmax(cmpme)
    
        return m_rec[idx], dataflow[idx]


def func_cima(acc0, gli, dataflow):
    m = sim.evaluate(acc0, gli, dataflow)
    return -m['throughput'], m['area'][7]*1e-6

def get_random_bool():
    dice = random()
    if dice<1/3: 
        return -1
    elif dice < 2/3: 
        return 0
    else:
        return 1


if __name__ == "__main__":
    model = ncfg.NN("./nn_config/bert_base_sl128.csv") 
    cim = ccfg.CIM("./cim_config/TranCIM.cfg")
    acc_trancim = ccfg.CIMACC(
        cim,
        bus_width = 25.6, 
        macro_row = 2, 
        macro_col = 2, 
        scr = 1, 
        is_size = 32, 
        os_size = 128, 
        freq=200
        ) 

    ee_L2, th, _, area = func_model(acc_trancim, model, 'throughput') 
    print(ee_L2, th)

    print(model.gli_list_rdc)
    print(model.gli_cnt)

